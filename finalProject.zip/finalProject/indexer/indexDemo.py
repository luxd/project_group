from corpus.parseCorpus import *
from indexer import *
import json


def main():
    pc = ParseCorpus()
    corpus = pc.get_corpus()
    idx = InvertedIndex()
    dlt = DocLenTable()
    index, dlt = build_indexer_lenTable(corpus)

    # for k, v in index:
    #    print(k, v)
    # print "indexer len is ", json.dump(index,sort_keys=True)
    print index.__len__()


if __name__ == '__main__':
    main()
