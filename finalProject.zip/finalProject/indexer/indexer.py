#This module contains 3 parts.
'''
a)	Class InvertedIndex is to make inverted index, including term frequency, which also has 2 function,
 get_tf() and get_df() are both getter functions to get term or document frenquency.

b)	class DocLenTable is to make a table of documents length. There are 2 functions inside this class.
get_length() is a getter function to return the length of document. get_average_length is to return
the average length of all documents.

c)	build_indexer_lenTable function is to use corpus as parameter to generate indexer and length table accordingly.

'''
import nltk
import string
from nltk.corpus import stopwords


class InvertedIndex:

	def __init__(self):
		self.index = dict()

	def __len__(self):
		return len(self.index)

	def __contains__(self, item):
		return item in self.index

	def __getitem__(self, item):
		return self.index[item]

	def add(self, word, docid):
		if word in self.index:
			if docid in self.index[word]:
				self.index[word][docid] += 1
			else:
				self.index[word][docid] = 1
		else:
			d = dict()
			d[docid] = 1
			self.index[word] = d

	#get term frequency in a document
	def get_tf(self, word, docid):
		if word in self.index:
			if docid in self.index[word]:
				return self.index[word][docid]
			else:
				raise LookupError('%s not in document %s' % (str(word), str(docid)))
		else:
			raise LookupError('%s not in index' % str(word))

	#get document frequency of word in collection
	def get_df(self, word):
		if word in self.index:
			return len(self.index[word])
		else:
			raise LookupError('%s not in index' % word)


class DocLenTable:

	def __init__(self):
		self.table = dict()

	def __len__(self):
		return len(self.table)

	def add(self, docid, length):
		self.table[docid] = length

	def get_length(self, docid):
		if docid in self.table:
			return self.table[docid]
		else:
			raise LookupError('%s not found in table' % str(docid))

	def get_average_length(self):
		sum = 0
		for length in self.table.itervalues():
			sum += length
		return float(sum) / float(len(self.table))


def build_indexer_lenTable(corpus):
	idx = InvertedIndex()
	dlt = DocLenTable()
	for docid in corpus:

		# Step 1: Tokenize
		tokens = nltk.word_tokenize(corpus[docid].body)

		tokens = [token for token in tokens if not token in string.punctuation]  # remove punctuation

		docLen = len(tokens) # document lenght in words

		# Step 2: lossy dictionary compression, including removing numbers, case folding, and stop word elimination

		tokens = [token for token in tokens if not any(c.isdigit() for c in token)]  # remove numbers

		tokens = [token.lower() for token in tokens]  # lowercase

		# stopwords 30
		'''
		stop = set(('a', 'an', 'and','are','as','at','be','by','for','from','has','he','in','is','it','its','of','on','that','the','to','was','were','will','with','why','where','just','which','very'))
		tokens = [token for token in tokens if token not in stop]  # stopwords 30
		'''
		# stopwords 150
		stop = set(stopwords.words('english'))
		tokens = [token for token in tokens if token not in stop]  # stopwords 150

		#build inverted index
		for word in tokens:
			#idx.add(str(word), str(docid))
			idx.add(word, docid)
		#build document length table
		#length of the document D in words
		dlt.add(docid, docLen)

	return idx, dlt