from corpus.parseCorpus import *
from sentiment.calAfinn import *

#rank all the depts by the afinn score
def main():
    pc = ParseCorpus()
    corpus = pc.get_corpus()

    afinnScores = calAfinn(corpus) #dict() including all scores of all docs, ordered by category
    deptSumScore = dict()
    for s in afinnScores: # s category name
        #print s[0:]
        deptSumScore[s[0:]] = 0
        for k in afinnScores[s[0:]]:
            #print afinnScores[s[0:]][k]
            deptSumScore[s[0:]] += afinnScores[s[0:]][k]


    #print each dept's afinn score by descending order
    for key, value in sorted(deptSumScore.iteritems()):
        print key + " - " + str(value)

    #print corpus[1].body
    #print categoryAfinn['biology'][4]
    #print len(categoryAfinn['biology'])
    #print categoryAfinn.keys()

if __name__ == '__main__':
    main()
