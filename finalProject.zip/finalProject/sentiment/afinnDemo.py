from corpus.parseCorpus import *
from sentiment.calAfinn import *
from sentiment.classifier import *
#rank all the depts by the afinn score
def main():
    pc = ParseCorpus()
    corpus = pc.get_corpus()

    afinnScores = calAfinn(corpus) #dict() including all scores of all docs, ordered by category
    deptSumScore = dict() # sum of afinn score for all docs for each dept
    deptTotalNeg = dict() # total num of how many negative words
    deptTotalPos = dict() # total num of how many positive words
    deptSumPosScore = dict() # sum positive score
    deptSumNegScore = dict() # sum of negative score

    for s in afinnScores: # s category name
        #print s
        deptSumScore[s] = 0
        deptTotalNeg[s] = 0
        deptTotalPos[s] = 0
        deptSumPosScore[s] = 0
        deptSumNegScore[s] = 0

        for k in afinnScores[s]: #[category][docid]
            #print afinnScores[s[0:]][k]
            t = afinnScores[s][k]

            #print t.score, t.positive, t.negative, t.sumPositive, t.sumNegative #getattr(t,"score")
            deptSumScore[s] += t.score
            deptTotalNeg[s] += t.negative
            deptTotalPos[s] += t.positive
            deptSumPosScore[s] += t.sumPositive
            deptSumNegScore[s] += t.sumNegative


    #print each dept's afinn score by descending order
    for key, value in sorted(deptSumScore.iteritems()):
        print key + " : Total Afinn Score: " + str(value)
    print "\n"

    for key, value in sorted(deptTotalNeg.iteritems()):
        print key + " : Total Num of Negative Words: " + str(value)
    print "\n"

    for key, value in sorted(deptTotalPos.iteritems()):
        print key + " : Total Num of Positive Words: " + str(value)
    print "\n"

    for key, value in sorted(deptSumPosScore.iteritems()):
        print key + " : Total Afinn Score of positive words: " + str(value)

    for key, value in sorted(deptSumNegScore.iteritems()):
        print key + " : Total Afinn Score of positive words: " + str(value)
    print "\n"

    #Classifier Result show
    for key, value in sorted(deptTotalPos.iteritems()):
        numNegative = deptTotalNeg.get(key)
        print key + " : " + classifier(value, numNegative) #positive - negative
    print "\n"

if __name__ == '__main__':
    main()

