from afinn import Afinn

def calAfinn(corpus):
    categories = dict()
    afinn = Afinn()
    for docid in corpus:
        category = corpus[docid].category


        body = corpus[docid].body
        score = afinn.score(body)
        if(category in categories):
            categories[category][docid] = score
        else:
            d = dict()
            d[docid] = score
            categories[category] = d



    return categories