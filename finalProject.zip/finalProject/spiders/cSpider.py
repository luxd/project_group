from scrapy.contrib.spiders import CrawlSpider, Rule
from scrapy.contrib.linkextractors.sgml import SgmlLinkExtractor
from scrapy.spider import BaseSpider
from scrapy.selector import HtmlXPathSelector
from finalProject.items import MyproItem
from scrapy.http import Request
import html2text

class CSpider(BaseSpider):
    name = "cSpider"
    allowed_domain = ["www.concordia.ca"]

    #category each start_url is a category
    #max max crawling pages for each category
    #corpusid one unique id for each categor, used for creating different docId for between differnet category
    #example crawl parameter scrapy crawl cSpider -a category=biology.html -a max=5 -a corpusid=1
    def __init__(self, starturl = '', category='', max =5, corpusid =1, *args, **kwargs):
        super(CSpider, self).__init__(*args, **kwargs)
        self.start_urls = ['http://www.concordia.ca/artsci/%s' % starturl]
        self.category = category #for pipeline and parse filter, remove .html from the input parameter
        self.COUNT_MAX = int(max)
        self.CORPUSID = int(corpusid)

        self.DOCIDOFFSET = (self.CORPUSID-1)*self.COUNT_MAX
        self.count = 1

    #start_urls = [
    #    "http://www.concordia.ca/artsci/biology.html"
    #]
    #COUNT_MAX = 5
    #count = 1

    #eg. biology docId -[1,5], and chemistry docId - [6-10] when max page is 5
    def start_requests(self):
        for u in self.start_urls:
            yield Request(u, callback=self.parse,
                                 meta={"index": self.count+self.DOCIDOFFSET},)

    def parse(self, response):
        hxs = HtmlXPathSelector(response)
        items = []
        urls = self.start_urls

        raw_id = response.meta["index"]
        raw_category = self.category
        raw_title = hxs.select('//title').extract()
        raw_url = response.url
        #extract body content and get text only without html tag
        raw_body = hxs.select('//body').extract()
        if(raw_body != ""):
            items.append(MyproItem(id = raw_id, category = raw_category, title=raw_title, url=raw_url, body=raw_body))

        raw_urls = hxs.select('//a/@href').extract()
        for url in raw_urls:
            if ('http' not in url):
                if ('artsci/'+self.category in url):
                    url = "http://www.concordia.ca" + url
                    if (url not in urls): # avoid duplicate
                        if (self.count < self.COUNT_MAX):
                            urls.append(url)
                            self.count = self.count + 1
                            items.append(Request(url, callback=self.parse, meta={"index": self.count+self.DOCIDOFFSET}),)



        return items

    # start_urls already in this list, so duplicate
    #