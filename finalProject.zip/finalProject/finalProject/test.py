

myStr = "[u'\n \n\t\t\n\t\t\n\t\t\n\t\t\n \n\n \n\n\n\n\n\n# Concordia University]"
myStr = myStr.replace("\n", " ")
print myStr.replace("\t"," ").replace(" ","")