import html2text
import re

class MyproPipeline(object):
    def __init__(self):  
        self.file = open('myProject.txt' , 'w')
        #self.file2 = open('zh.txt' , 'w')
    def process_item(self, item, spider):  
        #self.file.write(item['id']+ '\n')
        #self.file.write(item['category'] + '\n')
        #self.file.write(item['title'] + '\n')
        #self.file.write(item['url'] + '\n')

        #convert body to text only, removing html tags
        h = html2text.HTML2Text()
        # Ignore converting links from HTML
        h.ignore_links = True


        title = str(h.handle(str(item['title'])))[3:-4]
        body = str(h.handle(str(item['body'])))[3:-4]
        body = body.replace("\n","").replace("\t","")
        body = body.replace("\\n", "").replace("\\t", "")
        body = body.replace("\\r", "")

        #while "\n" in body: body.remove("\n")

        line = """<CONCORDIA NEWID={id}>
                <TITLE>{title}</TITLE>
                <URL>{url}</URL>
                <CATEGORY>{category}</CATEGORY>
                <BODY>{body}</BODY>
                </CONCORDIA>""".format(id=item['id'],title=title,url=item['url'],category=item['category'],body=body)


        self.file.write(line)

        return item  