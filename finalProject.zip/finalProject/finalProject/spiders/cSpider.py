from scrapy.contrib.spiders import CrawlSpider, Rule
from scrapy.contrib.linkextractors.sgml import SgmlLinkExtractor
from scrapy.spider import BaseSpider
from scrapy.selector import HtmlXPathSelector
from finalProject.items import MyproItem
from scrapy.http import Request
import html2text

class HjSpider(BaseSpider):
    name = "cSpider"
    allowed_domain = ["www.concordia.ca"]
    start_urls = [
        "http://www.concordia.ca/artsci/biology.html"
    ]
    COUNT_MAX = 5
    count = 1

    def start_requests(self):
        for u in self.start_urls:
            yield Request(u, callback=self.parse,
                                 meta={"index": 1},)

    def parse(self, response):
        hxs = HtmlXPathSelector(response)
        items = []
        urls = self.start_urls

        raw_id = response.meta["index"]
        raw_category = "biology"
        raw_title = hxs.select('//title').extract()
        raw_url = response.url
        #extract body content and get text only without html tag
        raw_body = hxs.select('//body').extract()

        items.append(MyproItem(id = raw_id, category = raw_category, title=raw_title, url=raw_url, body=raw_body))

        raw_urls = hxs.select('//a/@href').extract()
        for url in raw_urls:
            if ('http' not in url):
                if ('artsci/biology' in url):
                    url = "http://www.concordia.ca" + url
                    if (url not in urls): # avoid duplicate
                        if (self.count < self.COUNT_MAX):
                            urls.append(url)
                            self.count = self.count + 1
                            items.append(Request(url, callback=self.parse, meta={"index": self.count}),)



        return items

    # start_urls already in this list, so duplicate
    #