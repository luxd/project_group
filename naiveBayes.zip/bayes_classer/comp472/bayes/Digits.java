package comp472.bayes;
/*
 *	Digits Class	
 *	Calculates the likelihoods using the training labels and training images
 *	 
 * 	Estimates whether an image is a digit (0-9)
 * 
 * 
 */

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

import javax.imageio.ImageIO;

public class Digits {
	
	final int IMG_WIDTH = 64;
	final int IMG_HEIGHT = 64;
	//Likelihoods for each class (0-9)
	double [][][] likelihoods = new double [10][IMG_WIDTH][IMG_HEIGHT];
	
	//Number of occurences of a class in the traininglabels file
	double [] numbers = new double [10];
	
	//priors P(class). The empirical frequencies of the classes
	double [] frequencies = new double[10];
	
	//total number of numbers in the traininglabels 
	double total = 10000;
	
	//This is a 10x10 matrix whose entry in row r and column c 
	//is the percentage of test images from class r that are classified as class c.
	//Indexed by [row][column] 
	double [][] confusion_matrix = new double [10][10];
	
	//new image from test images (new number)
	double [][] image = new double[IMG_WIDTH][IMG_HEIGHT];
	
	double actualNum = 0; // The actual class of the current digit
	double percent = 0; // The counter for the number of correct classifications
	double count = 0; // A counter for the number of digits
	double smooth = 1;
	
	public static void main(String[] args) throws IOException 
	{
		//Classify Digits
		Digits digit_classification = new Digits();
		digit_classification.updateLikelihoods();
		digit_classification.accuracyCheck();
	}
	
	/**
	 * Smooth the likelihoods to ensure that there are no zero count.
	 * Adding a constant K to each pixel.
	 */
	public void smoothLikelihoods() {

		for(int i =0; i < 10; i++) {
			for(int j =0; j < IMG_WIDTH; j++) {
				for(int k =0; k < IMG_HEIGHT; k++) {
					likelihoods[i][j][k] = smooth;
				}
			}			
		}
	}
	
	/**
	 * A function to calculate the likelihoods using the training
	 * data in the specified files.
	 * 
	 * The images are 28x28, so we need to read the image textfile
	 * 28 lines at a time.
	 * 
	 * This function simply counts the number of occurrences of
	 * non-blank symbols for each image, and adds them to the likelihoods.
	 * 
	 * It also counts the number of occurrences of each class, storing 
	 * them into numbers[].
	 * 
	 * @throws IOException
	 */
	public void initLikelihoods() throws IOException {
        FileReader inputStream = new FileReader("processeddata/trainingimg");
        Scanner labels = new Scanner(new File("processeddata/traininglabel"));
        
        int c;
        int index = labels.nextInt();
        
        outerloop:
        for(int i = 0; true; i++){	        	
			for(int j =0; j < IMG_WIDTH; j++) { 
				c =  inputStream.read(); //read a character
				//System.out.println("" + j + ":" + c + " ");
				switch (c) {
				case -1: //end
					numbers[index]++;
					break outerloop;
				case 35:
				case 49: //value = 1					
					likelihoods[index][i%IMG_HEIGHT][j]++;
				}
			}
			inputStream.read(); //after each line, there are 2 chars, value 13 10
			inputStream.read();

			if(i%IMG_HEIGHT == 0 && i != 0) {
				numbers[index]++;

				if (!labels.hasNextInt())
					break outerloop;
				else
					index = labels.nextInt();
			}
		}	
        
       //System.out.println(likelihoods[0][0][35]);
	}
	
	
	/**
	 * Initializes the likelihood array that contains that 
	 * contains the likelihoods for each class (i.e. classes 0-9)
	 */
	public Digits() throws IOException {
		smoothLikelihoods();
		initLikelihoods();
	}
	
	
	/**
	 * Estimate the likelihoods P(F_ij | class), and adds smoothing. 
	 * As well as calculates the frequencies.
	 * 
	 *  - i = the number(class) we are going to update
	 *  
	 *  Calculate the frequencies of each number(Prior P(class))
	 *  Simply equal to (# of occurrences of each number)/(# total numbers)
	 *  
	 *  Updates the likelihoods by dividing each F_{i,j} by the number of 
	 *  occurrences of that class to get P(F_{i,j} | class)
	 */
	public void updateLikelihoods() {
		for(int i =0; i < 10; i++) {
			frequencies[i]= (double)(numbers[i])/(total);

			for(int j =0; j < IMG_WIDTH; j++) {
				for(int k =0; k < IMG_HEIGHT; k++) {		
					likelihoods[i][j][k] = (double)(likelihoods[i][j][k])/(numbers[i]+(2*smooth));					
				}
			}
			System.out.println("Num "+ i+ ": "+numbers[i]);
		}
	}
	
	/**
	 * Arrcuracy check for the training data
	 * @throws IOException
	 */
	public void accuracyCheck() throws IOException
	{
        FileReader inputNumber = new FileReader("processeddata/trainingimg");
        Scanner actualNumber = new Scanner(new File("processeddata/traininglabel"));
		//FileReader inputNumber = new FileReader("processeddata/testimages");
		//Scanner actualNumber = new Scanner(new File("processeddata/testlabels"));

        int c;
		
        outerloop:
        for(int i = 0; true; i++) {		 
			if(i %IMG_HEIGHT == 0 && i != 0) {
				if (!actualNumber.hasNextInt())
					break outerloop;
				else
					actualNum = actualNumber.nextInt();
			}
			
			for(int j =0; j < IMG_WIDTH; j++) {

				c =  inputNumber.read();
				
				switch (c) {
				case -1:
					pickClass(c);
					break outerloop;
				case 35:
				case 49: //value = 1
					image[i%IMG_HEIGHT][j] = 1;
					break;
				case 32: //value = empty space
					image[i%IMG_HEIGHT][j] = 0;
					break;
				}
			}
			inputNumber.read(); //after each line, there are 2 chars, value 13 10
			inputNumber.read();
			

			if(i %IMG_HEIGHT==0 && i !=0)
				pickClass(1);
		}
        
       	
	}
	
	
	/**
	 * Picks a class for a particular test case. (estimates)
	 * - i = the number(class) we are going to estimate
	 */
	public void pickClass( int input)
	{
		double[] probabilities = new double[10];
		int best = 0;
		
		for(int i =0; i < 10; i++) {
			probabilities[i]= probabilities[i] + (Math.log(frequencies[i]) );
			
			for(int j =0; j < IMG_WIDTH; j++) {
				for(int k =0; k < IMG_HEIGHT; k++) {
					if(image[j][k]==0)
					probabilities[i] = probabilities[i] + ( Math.log(1-likelihoods[i][j][k]));
					else
						probabilities[i] = probabilities[i] + ( Math.log(likelihoods[i][j][k]));
				}
			}
			
			if(probabilities[i] > probabilities[best])
				best = i;
			
		}

		if(best == actualNum) {
			percent++;	
		}
		
		confusion_matrix[best][(int)actualNum]++;
		count++;
		
		if(input ==-1) {
			printResults();
		}
	}
	

	
	/**
	 * Prints the resulting statistics of the
	 * digit classification. 
	 */
	public void printResults() {
		System.out.println("Digit Classification: ");
		System.out.println("Count: " +percent+" / "+count);
		System.out.println("Percent: "+ (float)(percent/count)*100);
		System.out.println("Confusion Matrix:");
		printConfusionMatrix();
		//printLikelihoodMaps();
		//printOddsRatios();
	}
	
	/**
	 * Converts each entry of the matrix to a percentage.
	 * Prints the confusion matrix.
	 */
	public void printConfusionMatrix() {
		int sum = 0;
		for (int j = 0; j < 10; j++) {
			for (int i = 0; i < 10; i++) {
				sum += confusion_matrix[i][j];
			}
			for (int i = 0; i < 10; i++) {
				confusion_matrix[i][j] = confusion_matrix[i][j]/sum;
			}
			sum = 0;
		}
		
		for (int i = 0; i < 10; i++) {
			for (int j = 0; j < 10; j++) {
				if ((100*(confusion_matrix[i][j])) >= 10)
					System.out.printf("%.1f ",(float)(100*(confusion_matrix[i][j])));
				else
					System.out.printf("%.1f  ",(float)(100*(confusion_matrix[i][j])));
			}
			System.out.println();
		}
		System.out.println();
	}
	
	/** 
	 * (DEBUGGING FUNCTION)
	 * Prints the array of likelihoods.
	 */
	public void printLikelihoods() {
		
		for(int i =0; i < 10; i++) {
			for(int j =0; j < IMG_WIDTH; j++) {
				for(int k =0; k < IMG_HEIGHT; k++) {
					//a threshold to see what the likelihoods look like
					if(likelihoods[i][j][k] > .5)
						System.out.print("#");
					else 
						System.out.print(" ");
				}
				System.out.println();
			}
			System.out.println();
			System.out.println();
		}
	}
}//end of class Digits
