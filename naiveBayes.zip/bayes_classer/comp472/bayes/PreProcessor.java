package comp472.bayes;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;

public class PreProcessor {

	public static void main(String[] args) {
		// to generate processed data, trainingimg and traininglabel
		File trainingimg = new File("processeddata/trainingimg");
		File traininglabel = new File("processeddata/traininglabel");
		FileWriter fstream = null;
		BufferedWriter out = null;
		FileWriter fstream2 = null; //writer for traininglabel
		BufferedWriter out2 = null;

		try {
			fstream = new FileWriter(trainingimg, false);//append false
			out = new BufferedWriter(fstream);
			fstream2 = new FileWriter(traininglabel, false); //append false
			out2 = new BufferedWriter(fstream2);
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		

		int numbers = 10;//0-9 folders
		for(int i = 0; i < numbers; i++){ 
			File folder = new File("rawdata/"+Integer.toString(i));
			File[] listOfFiles = folder.listFiles();
			//System.out.println(listOfFiles.length);
			    for(File f : listOfFiles) {
			    	//System.out.println(f.getName());
			    	if (f.isFile() && "txt".equals(getFileExtension(f))){
			    		//System.out.println(f.getName());
						FileInputStream fis;
						try {
							fis = new FileInputStream(f);
							BufferedReader in = new BufferedReader(new InputStreamReader(fis));
			 
							String aLine;
							while ((aLine = in.readLine()) != null) {
								out.write(aLine);
								out.newLine();	
							}
							
							out2.write(Integer.toString(i));
							out2.newLine();
			 
							in.close();
						} catch (IOException e) {
							e.printStackTrace();
						}
						
			    	  
			    	} else if (f.isDirectory()) {
			    		System.out.println("Directory is not allowed");
			    	}
			    }			
		}

		try {
			out.close();
			out2.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

		System.out.println("Done");
	}//end of main()
	
	private static String getFileExtension(File file) {
        String fileName = file.getName();
        if(fileName.lastIndexOf(".") != -1 && fileName.lastIndexOf(".") != 0)
        return fileName.substring(fileName.lastIndexOf(".")+1);
        else return "";
    }

}


