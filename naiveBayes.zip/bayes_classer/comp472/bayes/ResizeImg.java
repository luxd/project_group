package comp472.bayes;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import javax.imageio.ImageIO;

public class ResizeImg {
	final static int IMG_WIDTH = 64;
	final static int IMG_HEIGHT = 64;

	public static void main(String[] args) throws IOException {
		// resize img using java.awt.Graphics2D
		
		//resize("rawdata/0/test.tif","rawdata/0/");
		int numbers = 10;//0-9 folders
		for(int i = 6; i < numbers; i++){ 
			File folder = new File("rawdata/"+Integer.toString(i));
			File[] listOfFiles = folder.listFiles();
			//System.out.println(listOfFiles.length);
			    for(File f : listOfFiles) {
			    	if("tif".equals(getFileExtension(f)))
			    		resize(f,"rawdata/"+Integer.toString(i)+"/");
			    }			    
		}
		
	}	
	
	public static void resize(File inputFile, String filefolder){
		try {
			// reads input image
			//File inputFile = new File(inputfile);
			System.out.println(inputFile.getName());
			BufferedImage originalImage = ImageIO.read(inputFile);
			
			
			// creates output image
	        BufferedImage outputImage = new BufferedImage(IMG_WIDTH,IMG_HEIGHT, BufferedImage.TYPE_BYTE_GRAY);
	        
	        // scales the input image to the output image
	        Graphics2D g2d = outputImage.createGraphics();
	        //g2d.setColor(Color.WHITE);
	        g2d.drawImage(originalImage, 0, 0, IMG_WIDTH, IMG_HEIGHT, null);
	        g2d.dispose();
	 
	        // writes to 01 binary file
	        String binFileName = inputFile.getName();
	        File binFile = new File(filefolder+binFileName+".txt");
	        
			FileWriter fstream = null;
			BufferedWriter out = null;
			try {
				fstream = new FileWriter(binFile, false); //append false
				out = new BufferedWriter(fstream);
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			
	        for(int i = 0; i < IMG_HEIGHT; i++){
	        	String aLine = "";
	        	for(int j = 0; j < IMG_WIDTH; j++){
	        		if(outputImage.getRGB(j,i) == -1) //getRGB(x,y), x from left to right, y from top to bottom
	        			aLine += " ";
	        		else
	        			aLine += "1";
	        	}
	        	out.write(aLine);
				out.newLine();
	        }
	        //System.out.println(outputImage);
	        //ImageIO.write(outputImage, "tif", new File("rawdata/0/test112.tif"));
		
			try {
				out.close();			
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		
		
	} //end of resize()
	
	
	private static String getFileExtension(File file) {
        String fileName = file.getName();
        if(fileName.lastIndexOf(".") != -1 && fileName.lastIndexOf(".") != 0)
        return fileName.substring(fileName.lastIndexOf(".")+1);
        else return "";
    }
	
}
