def classifier(Npositive, Nnegative):
    if(Npositive > Nnegative):
        return " is classified to POSITIVE"
    elif(Npositive == Nnegative):
        return " is classified to NEUTUAL"
    else:
        return " is classified to NEGATIVE"