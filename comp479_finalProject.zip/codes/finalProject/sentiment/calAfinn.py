from afinn import Afinn
from docsentiment import docsentiment
def calAfinn(corpus):
    categories = dict() #total score for each doc

    for docid in corpus:
        category = corpus[docid].category
        body = corpus[docid].body
        #score = afinn.score(body)
        #d = dict()
        docsent = docsentiment(body)
        #categories[category][docid] = d
        if (category in categories):
            categories[category][docid] = docsent
        else:
            d = dict()
            d[docid] = docsent
            categories[category] = d





    return categories


