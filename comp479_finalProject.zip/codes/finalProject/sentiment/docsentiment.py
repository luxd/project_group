from afinn import Afinn
import nltk
import string
class docsentiment:
    def __init__(self, body):
        self.positive = 0
        self.sumPositive = 0
        self.negative = 0
        self.sumNegative = 0
        self.score = 0
        self.body = body
        self.calculate()

    def calculate(self):
        afinn = Afinn()
        self.score = afinn.score(self.body)
        tokens = nltk.word_tokenize(self.body)
        #tokens = [token for token in tokens if not token in string.punctuation]  # remove punctuation
        #tokens = [token for token in tokens if not any(c.isdigit() for c in token)]  # remove numbers
        #tokens = [token.lower() for token in tokens]  # lowercase
        for token in tokens:
            tokenscore = afinn.score(token)
            if tokenscore > 0:
                self.positive += 1
                self.sumPositive += tokenscore
            elif tokenscore < 0: #no equal, remove
                self.negative += 1
                self.sumNegative += tokenscore

