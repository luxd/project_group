from corpus.parseCorpus import *
from indexer import *
import json


def main():
    pc = ParseCorpus()
    corpus = pc.get_corpus()
    idx = InvertedIndex()
    dlt = DocLenTable()
    index, dlt = build_indexer_lenTable(corpus)

    # for k, v in index:
    #    print(k, v)
    # print "indexer len is ", json.dump(index,sort_keys=True)
    # write to index file
    file = open('index.txt', 'a+')

    # write to file and calculate the number of postings
    numpostings = 0
    for key, value in sorted(index.index.iteritems()):
        file.write(str(key) + ":" + str(index[key]) + "\n")
        numpostings += len(value)
    file.close()
    # print how many terms and postings in total
    print "There are in total ", len(index), "terms in the index."
    print "There are in total ", numpostings, "postings."
    #print index.__len__()


if __name__ == '__main__':
    main()
