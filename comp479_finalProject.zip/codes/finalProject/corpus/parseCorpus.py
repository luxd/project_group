'''
This file is from previous project 1. It is to extract all the reuters contents and
parse them into dictionary type data.
'''

from xml.dom import minidom
import os
class ParseCorpus:
    def __init__(self):
        # self.filename = filename
        # self.regex = re.compile('^#\s*\d+')
        self.corpus = self.getDocuments()

    def get_corpus(self):
        return self.corpus

    # Extract body contents from each reuter
    # documents is dictionary data structure, key is NEWID, and the value is the content of BODY of each reuter
    def getDocuments(self):
        filenames = ["biology-1.txt", "chemistry-2.txt", "exercise-science-3.txt", "geography-planning-environment-4.txt",
                     "math-stats-5.txt", "physics-6.txt", "psychology-7.txt", "science-college-8.txt","science-college-9.txt",
                    ]

        #filenames = ["test.txt", "test2.txt"]
        #filenames = ["reut2-022.sgm"]
        #use dictionary to store documents
        documents = {}


        for filename in filenames:
            #read the file and put it to text string
            #file2str = open("finalProject/finalProject/corpus/"+filename).read()
            __location__ = os.path.realpath(
                os.path.join(os.getcwd(), os.path.dirname(__file__)))
            file2str = open(os.path.join(__location__, filename)).read()
            #find the index of the first <CONCORDIA, then add <data>  from that point, and add </data> at the end
            #to make it compatible with XML format
            index = file2str.find('<CONCORDIA')
            myfile = file2str[:index] + '<data>' + file2str[index:] + '</data>'
            #to make it compatible with XML, then use minidom to parse XML, XML parser can't handle &, escape it
            myfile = myfile.replace('&', '&amp;')
            #reut2-017.sgm has the unicode problem, xml parser can't deal with it
            myfile = unicode(myfile, errors='ignore')

            xmldoc = minidom.parseString(myfile)

            webslists = xmldoc.getElementsByTagName('CONCORDIA')

            #print webslists.length
            for weblists in webslists:


                if weblists.getElementsByTagName('BODY').length > 0:
                    bodyDOM = weblists.getElementsByTagName('BODY')[0]
                    body = bodyDOM.childNodes[0].nodeValue
                    #print body.childNodes[0].nodeValue
                else:
                    body = ""

                if weblists.getElementsByTagName('TITLE').length > 0:
                    titleDOM = weblists.getElementsByTagName('TITLE')[0]
                    title = titleDOM.childNodes[0].nodeValue
                    #print body.childNodes[0].nodeValue
                else:
                    title = ""

                if weblists.getElementsByTagName('URL').length > 0:
                    urlDOM = weblists.getElementsByTagName('URL')[0]
                    url = urlDOM.childNodes[0].nodeValue
                    # print body.childNodes[0].nodeValue
                else:
                    url = ""

                if weblists.getElementsByTagName('CATEGORY').length > 0:
                    categoryDOM = weblists.getElementsByTagName('CATEGORY')[0]
                    category = categoryDOM.childNodes[0].nodeValue
                    # print body.childNodes[0].nodeValue
                else:
                    category = ""


                newId = int(weblists.getAttributeNode("NEWID").nodeValue)
                #print newId

                myWeb = WebPage(newId, url, category, title, body)
                documents[newId] = myWeb

        return documents




class WebPage:
    def __init__(self, id, url, category, title, body):
        self.id = id
        self.url = url
        self.category = category
        self.title = title
        self.body = body
